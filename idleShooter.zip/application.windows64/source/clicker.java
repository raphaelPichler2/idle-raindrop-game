import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class clicker extends PApplet {


long points;
float screenSize=1;
float pointsPKill;
float dropspeed;
float nextDrop;
float BigDspeed;
float nextBigD;
float nextGlowD;
float GlowDspeed;
float nextShower=20*60;
boolean showering=false;
float ShowerTime;
float nextHalo;
float HaloSpeed;

Table table;

int frames=0;

canon canon1 = new canon();
Boolean[] keys= new Boolean[3];
ArrayList<Bullet> bullets=new ArrayList();
ArrayList<Drops> drops =new ArrayList();
SaceMenu savemenu = new SaceMenu();
Shop shop = new Shop();

PImage canonI;
PImage dropI;
PImage ballI;
PImage bigDropI;
PImage bulletI;
PImage glowDropI;
PImage backgroundI;
PImage showerI;
PImage BombI;
PImage HaloI;

public void setup(){
  
  rectMode(CENTER);
  textAlign(CENTER,CENTER);
  imageMode(CENTER);
  table= loadTable("new.csv","header,csv");
  points=table.getInt(0,"value");
  shop.ASUp=table.getInt(1,"value");
  shop.MSUp=table.getInt(2,"value");
  shop.RDUp=table.getInt(3,"value");
  shop.BBUp=table.getInt(4,"value");
  shop.BDUp=table.getInt(5,"value");
  shop.PKUp=table.getInt(6,"value");
  shop.PMUp=table.getInt(7,"value");
  shop.BBulletsUp=table.getInt(8,"value");
  shop.GlowDUp=table.getInt(9,"value");
  shop.TrinityUp=table.getInt(10,"value");
  shop.ShowerUp=table.getInt(11,"value");
  shop.BombsUp=table.getInt(12,"value");
  shop.HaloDUp=table.getInt(13,"value");
  
  canon1.attackspeed=80*(float)Math.pow(1.2f,shop.ASUp);
  canon1.speed=5*(float)Math.pow(1.2f,shop.MSUp);
  canon1.ballAS=14*(float)Math.pow(1.5f,shop.BBUp);
  canon1.bulletSize=20*(float)Math.pow(1.2f,shop.BBulletsUp);
  canon1.trinityChance=25*shop.TrinityUp;
  canon1.bombAS=3*(float)Math.pow(1.5f,shop.BombsUp);
  
  pointsPKill=(float)(1*Math.pow(1.2f,shop.PKUp));
  dropspeed=50*(float)Math.pow(1.2f,shop.RDUp);
  nextDrop=60;
  BigDspeed=4*(float)Math.pow(1.5f,shop.BDUp);
  nextBigD=120;
  GlowDspeed=2*(float)Math.pow(1.5f,shop.GlowDUp);
  nextGlowD=20*60;
  ShowerTime=3.5f+1.5f*shop.ShowerUp;
  HaloSpeed=2*(float)Math.pow(1.5f,shop.HaloDUp);
  nextHalo=3600/2;
  
  keys[0]=false;
  keys[1]=false;
  keys[2]=false;
  
  canonI=loadImage("canon.png");
  dropI=loadImage("Drop.png");
  ballI=loadImage("ball.png");
  bigDropI=loadImage("bigDrop.png");
  bulletI=loadImage("Bullet.png");
  glowDropI=loadImage("glowDrop.png");
  backgroundI=loadImage("background.png");
  showerI=loadImage("shower.png");
  BombI=loadImage("Bomb.png");
  HaloI=loadImage("Halo.png");
}
public void draw(){
  image(backgroundI,400,400);
  if(showering){
    image(showerI,400,400);
  }
  if(frames>0)frames--;
  
  ArrayList<Bullet> bullets1=bullets;
  for(int i=0; i<bullets1.size();i++){
    bullets1.get(i).draw();
  }
  if(shop.ShowerUp>0){
    if(nextShower<=0){
      showering=!showering;
      if(showering){
        nextShower=ShowerTime*60;
      }else nextShower=(16+random(0,28))*60;
    }else nextShower--;
  }
  
  newDrops();
  ArrayList<Drops> drops1=drops;
  for(int i=0;i<drops1.size();i++){
    drops1.get(i).draw();
  }
  
  canon1.draw();
  
  textSize(22);
  fill(0);
  textAlign(LEFT,CENTER);
  text((int)points,20,30);
  textAlign(CENTER,CENTER);
  
  savemenu.draw();
  shop.draw();
  table.getRow(0).setLong("value",points);
}
public void newDrops(){
  if(nextDrop<=0){
    Drops drop1=new Drops();
    nextDrop=3600/dropspeed;
    if(showering)nextDrop=nextDrop/3;
  }else{
    nextDrop--;
  }
  
  if(nextBigD<=0 && shop.BDUp>0){
    BigDrop bigDrop1=new BigDrop();
    nextBigD=3600/BigDspeed;
    if(showering)nextBigD=nextBigD/3;
  }else{
    nextBigD--;
  }
  
  if(nextGlowD<=0 && shop.GlowDUp>0){
    int r=(int)random(10000);
    for(int i=0;i<20;i++){
      GlowBullet glowDrop1=new GlowBullet(20+40*i,r);
    }
    nextGlowD=3600/GlowDspeed;
    if(showering)nextGlowD=nextGlowD/3;
  }else{
    nextGlowD--;
  }
  
  if(nextHalo<=0 && shop.HaloDUp>0){
    HaloDrop glowDrop1=new HaloDrop();
    nextHalo=3600/HaloSpeed;
    if(showering)nextHalo=nextHalo/3;
  }else{
    nextHalo--;
  }
}

public void keyPressed(){
  if(key=='a')keys[0]=true;
  if(key=='d')keys[1]=true;
  if(key==' ')keys[2]=true;
}
public void keyReleased(){
  if(key=='a')keys[0]=false;
  if(key=='d')keys[1]=false;
  if(key==' ')keys[2]=false;
}
class Ball extends Bullet{
  
  Ball(float x, float y,float sx, float sy){
    super(x,y,sx,sy,40/screenSize,0);
    oneHit=false;
  }
  
  public void draw(){
    posX=posX+speedX;
    posY=posY+speedY;
    fill(0xffFF0808);
    image(ballI,posX,posY,size,size);
    if(posX>800-size/2 && speedX>0 || posX<size/2 && speedX<0 )speedX=speedX*-1;
    if(posY<size/2)speedY=speedY*-1;
    if(posY>=710 && posY<=710+speedY && posX<canon1.posX+25 && posX>canon1.posX-25 && speedY>0){
      if(speedX<0)speedX=random(-12,1);
      else speedX=random(1,12);
      speedY=-8;
      float param = 10 / (float)Math.sqrt(Math.pow(speedX,2)+Math.pow(speedY,2));
      speedX=speedX*param;
      speedY=speedY*param;
    }
    else{
      if(posY>=710 && posY<=710+size/2+speedY && posX<canon1.posX+25+size/2 && posX>canon1.posX-25-size/2 && speedY>0){
        if(speedX<0)speedX=random(-12,1);
        else speedX=random(1,12);
        speedY=-8;
        float param = 10 / (float)Math.sqrt(Math.pow(speedX,2)+Math.pow(speedY,2));
        speedX=speedX*param;
        speedY=speedY*param;
      }
    }
    if(posY>800+size){
      bullets.remove(this);
    }
  }
}
class BigDrop extends Drops{

  ArrayList<Bullet> deactiveBullets=new ArrayList();
  
  BigDrop(){
    super();
    size=60/screenSize;
    speed=3/screenSize;
    posY=-size;
    posX=random(0,800);
    Hp=10;
    pointBonus=55;
  }
  
  public void draw(){
    if(Hp<=0){
      drops.remove(this);
      points=points+(int)(pointBonus*pointsPKill);
    }
    posY=posY+speed;
    size=(60-40+4*Hp)/screenSize;
    fill(0xff55A8FF);
    image(bigDropI,posX,posY,size,size);
    hitDetect();
    if(posY>800+size/2){
      if(shop.PMUp>0)points=points+(int)(0.2f*(float)Math.pow(1.5f,shop.PMUp-1)*pointBonus*pointsPKill);
      drops.remove(this);
    }
  }
  
  public void hitDetect(){
    for(int i=0;i<bullets.size();i++){
      if(deactiveBullets.contains(bullets.get(i)) && Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) > 1+(this.size+bullets.get(i).size)/2){
        deactiveBullets.remove(bullets.get(i));
      }
      
      if(Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) <= (this.size+bullets.get(i).size)/2 && !deactiveBullets.contains(bullets.get(i))){
        deactiveBullets.add(bullets.get(i));
        Hp=Hp-bullets.get(i).dmg;
        if(bullets.get(i).oneHit)bullets.remove(i);
      }
    }
  }
}
class Bomb extends Bullet{
  
  int timer;
  int exploTimer;
  
  Bomb(float x, float y,float sx, float sy){
    super(x,y,sx,sy,90/screenSize,0);
    oneHit=false;
    timer=7*60;
    dmg=0;
    exploTimer=-1;
  }
  
  public void draw(){
    if(timer<=0 && exploTimer<0){
      exploTimer=6;
      dmg=40;
      size=900/screenSize;
    }else timer--;
    
    if(exploTimer>0){
      fill(0xffFFFFFF);
      ellipse(posX,posY,size,size);
      exploTimer--;
      if(exploTimer<=0)bullets.remove(this);
    }else{
      
    posX=posX+speedX;
    posY=posY+speedY;
    fill(0);
    image(BombI,posX,posY);
    fill(0xffED0707);
    textSize(20);
    text((int)(timer/60),posX,posY-2);
    if(posX>800-size/2 && speedX>0 || posX<size/2 && speedX<0 )speedX=speedX*-1;
    if(posY<size/2)speedY=speedY*-1;
    if(posY>=710 && posY<=710+speedY && posX<canon1.posX+25 && posX>canon1.posX-25 && speedY>0)speedY=speedY*-1;
    else{
      if(posY>=710 && posY<=710+size/2+speedY && posX<canon1.posX+25+size/2 && posX>canon1.posX-25-size/2 && speedY>0)speedY=speedY*-1;
    }
    if(posY>800+size){
      bullets.remove(this);
    }
    
    }
  }
}
class Bullet{
  
  float posX;
  float posY;
  float speedX;
  float speedY;
  float size;
  boolean oneHit;
  float rotate;
  int dmg;
  
  Bullet(float x, float y, float speedX, float speedY,float size,float rotate){
    posX=x;
    posY=y;
    this.speedX=speedX/screenSize;
    this.speedY=speedY/screenSize;
    this.size=size/screenSize;
    this.rotate=rotate;
    oneHit=true;
    dmg=1;
    bullets.add(this);
  }
  
  public void draw(){
    posX=posX+speedX;
    posY=posY+speedY;
    pushMatrix();
    translate(posX,posY);
    rotate(radians(rotate));
    fill(0xffFDFFE0);
    image(bulletI,0,0,size,size);
    popMatrix();
    if(posX>800+size || posX<0-size || posY<0-size){
      bullets.remove(this);
    }
  }
}
class Drops{
  
  float posX;
  float posY;
  float pointBonus;
  float speed;
  float size;
  int Hp;
  
  Drops(){
    size=30/screenSize;
    posY=-size;
    posX=random(0,800);
    pointBonus=5;
    speed=7/screenSize;
    Hp=1;
    drops.add(this);
  }
  
  public void draw(){
    if(Hp<=0){
      drops.remove(this);
      points=points+(int)(pointBonus*pointsPKill);
    }
    posY=posY+speed;
    fill(0xff52E4FF);
    image(dropI,posX,posY,size,size);
    hitDetect();
    if(posY>800+size/2){
      if(shop.PMUp>0)points=points+(int)(0.2f*(float)Math.pow(1.5f,shop.PMUp-1)*pointBonus*pointsPKill);
      drops.remove(this);
    }
  }
  
  public void hitDetect(){
    for(int i=0;i<bullets.size();i++){
      if(Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) < (this.size+bullets.get(i).size)/2){
        Hp=Hp-bullets.get(i).dmg;
        if(bullets.get(i).oneHit)bullets.remove(i);
      }
    }
  }
}
class GlowBullet extends Drops{
  
  int number;
  float pointBonus2;
  
  GlowBullet(float x,int number){
    super();
    pointBonus=5;
    pointBonus2=450;
    speed=6/screenSize;
    posX=x;
    this.number=number;
  }
  
  public void draw(){
    if(Hp<=0){
      int dropsLeft=0;
      for(int n=0;n<drops.size();n++){
        if(drops.get(n) instanceof GlowBullet)dropsLeft++;
      }
      if(dropsLeft<=0)points=points+(int)(pointBonus2*pointsPKill);
      drops.remove(this);
      points=points+(int)(pointBonus*pointsPKill);
    }
    posY=posY+speed;
    fill(0xff4BFF55);
    image(glowDropI,posX,posY,size*1.2f,size*1.2f);
    hitDetect();
    if(posY>800){
      if(shop.PMUp>0)points=points+(int)(0.2f*(float)Math.pow(1.5f,shop.PMUp-1)*pointBonus*pointsPKill);
      drops.remove(this);
    }
  }
  
  public void hitDetect(){
    for(int i=0;i<bullets.size();i++){
      if(Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) < (this.size+bullets.get(i).size)/2){
        Hp=Hp-bullets.get(i).dmg;
        if(bullets.get(i).oneHit)bullets.remove(i);
      }
    }
  }
}
class HaloDrop extends Drops{
  
  float speedX;
  float speedY;
  
  ArrayList<Bullet> deactiveBullets=new ArrayList();
  
  HaloDrop(){
    super();
    size=160;
    speedX=6/screenSize;
    speedY=2.5f/screenSize;
    posY=-size;
    posX=random(0,800);
    Hp=80;
    pointBonus=6050;
  }
  
  public void draw(){
    if(Hp<=0){
      drops.remove(this);
      points=points+(int)(pointBonus*pointsPKill);
    }
    posX=posX+speedX;
    posY=posY+speedY;
    if(posX>800-size/2 && speedX>0 || posX<size/2 && speedX<0 )speedX=speedX*-1;
    size=(160-80+1*Hp)/screenSize;
    fill(0xff55A8FF);
    image(HaloI,posX,posY,size,size);
    hitDetect();
    if(posY>800+size/2){
      if(shop.PMUp>0)points=points+(int)(0.2f*(float)Math.pow(1.5f,shop.PMUp-1)*pointBonus*pointsPKill);
      drops.remove(this);
    }
  }
  
  public void hitDetect(){
    for(int i=0;i<bullets.size();i++){
      if(deactiveBullets.contains(bullets.get(i)) && Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) > 1+(this.size+bullets.get(i).size)/2){
        deactiveBullets.remove(bullets.get(i));
      }
      
      if(Math.sqrt(Math.pow(posX-bullets.get(i).posX,2)+Math.pow(posY-bullets.get(i).posY,2)) <= (this.size+bullets.get(i).size)/2 && !deactiveBullets.contains(bullets.get(i))){
        if(!(bullets.get(i) instanceof Bomb))deactiveBullets.add(bullets.get(i));
        Hp=Hp-bullets.get(i).dmg;
        if(bullets.get(i).oneHit)bullets.remove(i);
      }
    }
  }
  
}
class SaceMenu{
  
  boolean info;
  
  public void draw(){
    if(mouseX>650 && mouseX<790){
      fill(0xffC6FFB9);
      rect(800,400,300,900);
      
      fill(0xffFFC4C5);
      rect(725,50,100,80);
      fill(0);
      textSize(20);
      text("save",725,50);
      if(mousePressed && mouseX<775&&675<mouseX && mouseY<90&&10<mouseY){
        saveTable(table, "data/new.csv");
        fill(0);
        rect(725,50,100,80);
        fill(0xffFFC4C5);
        text("save",725,50);
      }
      
      fill(0xffFFC4C5);
      rect(725,150,100,80);
      fill(0);
      textSize(20);
      text("restart",725,150);
      if(mousePressed && mouseX<775&&675<mouseX && mouseY<190&&110<mouseY){
        points=0;
        table.getRow(0).setLong("value",points);
        shop.ASUp=0;
        canon1.attackspeed=80;
        table.getRow(1).setInt("value",shop.ASUp);
        shop.MSUp=0;
        canon1.speed=5;
        table.getRow(2).setInt("value",shop.MSUp);
        shop.RDUp=0;
        dropspeed=50;
        table.getRow(3).setInt("value",shop.RDUp);
        shop.BBUp=0;
        canon1.ballAS=14;
        table.getRow(4).setInt("value",shop.BBUp);
        shop.BDUp=0;
        BigDspeed=4;
        table.getRow(5).setInt("value",shop.BDUp);
        shop.PKUp=0;
        pointsPKill=1;
        table.getRow(6).setInt("value",shop.PKUp);
        shop.PMUp=0;
        table.getRow(7).setInt("value",shop.PKUp);
        shop.BBulletsUp=0;
        canon1.bulletSize=20;
        table.getRow(8).setInt("value",shop.PKUp);
        shop.GlowDUp=0;
        GlowDspeed=2;
        table.getRow(9).setInt("value",shop.GlowDUp);
        shop.TrinityUp=0;
        canon1.trinityChance=0;
        table.getRow(10).setInt("value",shop.TrinityUp);
        shop.ShowerUp=0;
        ShowerTime=0;
        table.getRow(11).setInt("value",shop.ShowerUp);
        shop.BombsUp=0;
        canon1.bombAS=3;
        table.getRow(12).setInt("value",shop.BombsUp);
        shop.HaloDUp=0;
        HaloSpeed=2;
        table.getRow(13).setInt("value",shop.HaloDUp);
        
        fill(0);
        rect(725,150,100,80);
        fill(0xffFFC4C5);
        text("restart",725,150);
      }
      
      fill(0xffFFC4C5);
      rect(725,250,100,80);
      fill(0);
      textSize(20);
      text("stats",725,250);
      if(mousePressed && mouseX<775&&675<mouseX && mouseY<290&&210<mouseY){
        info=true;
        shop.inShop=false;
      }
    }
    if(info)drawInfo();
  }
  
  public void drawInfo(){
    background(0xffC6EFFF);
    
    textSize(22);
    fill(0);
    textAlign(LEFT,CENTER);
    text(points,20,20);
    textAlign(RIGHT,CENTER);
    
    text("attackspeed: "+canon1.attackspeed,400,50);
    text("bulletsize: "+ canon1.bulletSize,400,100);
    text("mobility: "+ canon1.speed,400,150);
    text("money per drop: "+ pointsPKill*5,400,200);
    text("trinity chance: "+ canon1.trinityChance+" %",400,250);
    
    textAlign(CENTER,CENTER);
  }
}
class Shop{
  boolean inShop=false;
  int ASUp=0;
  int MSUp=0;
  int RDUp=0;
  int BBUp=0;
  int BDUp=0;
  int PKUp=0;
  int PMUp=0;
  int BBulletsUp=0;
  int GlowDUp=0;
  int TrinityUp=0;
  int ShowerUp=0;
  int BombsUp=0;
  int HaloDUp=0;
  
  int ASUpP=50;
  int MSUpP=60;
  int RDUpP=70;
  int PKUpP=80;
  int BBUpP=260;
  int ShowerUpP=400;
  int BDUpP=520;
  int BBulletsUpP=640;
  int PMUpP=1100;
  int TrinityUpP=6600;
  int GlowDUpP=11000;
  int BombsUpP=65000;
  int HaloDUpP=110000;
  
  public void draw(){
    if(inShop){
      drawShop1();
    }
      
    if(mouseX<150 && mouseX>10){
      fill(0xffC6FFB9);
      rect(0,400,300,900);
    
      fill(0xffFFC4C5);
      rect(75,50,100,80);
      fill(0);
      textSize(20);
      text("continue",75,50);
      if(mousePressed && mouseX<125&&25<mouseX && mouseY<90&&10<mouseY && frames<=0){
        inShop=false;
        savemenu.info=false;
        frames=15;
        fill(0);
        rect(75,50,100,80);
        fill(0xffFFC4C5);
        text("continue",75,50);
      } 
      
      fill(0xffFFC4C5);
      rect(75,150,100,80);
      fill(0);
      textSize(20);
      text("shop 1",75,150);
      if(mousePressed && mouseX<125&&25<mouseX && mouseY<190&&110<mouseY && frames<=0){
        inShop=true;
        frames=15;
        fill(0);
        rect(75,150,100,80);
        fill(0xffFFC4C5);
        text("shop 1",75,150);
      }
    }
  }
  
  public void drawShop1(){
    background(0xffC6EFFF);
    
    textSize(22);
    fill(0);
    textAlign(LEFT,CENTER);
    text((int)points,20,20);
    textAlign(CENTER,CENTER);
    
    fill(0xffC6EFFF);
    rect(220,50,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("attackspeed +20%",180,50);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(2,ASUp)*ASUpP)fill(0);
    text((int)Math.pow(2,ASUp)*ASUpP,220,50);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<66&&36<mouseY && frames<=0 && points>=(int)Math.pow(2,ASUp)*ASUpP){
      frames=15;
      points=points-(int)Math.pow(2,ASUp)*ASUpP;
      canon1.attackspeed=canon1.attackspeed*1.2f;
      ASUp++;
      table.getRow(1).setInt("value",ASUp);
      fill(0xffFFFFFF);
      rect(220,50,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("attackspeed +10%",180,50);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(2,ASUp)*ASUpP,220,50);
    }
    
    fill(0xffC6EFFF);
    rect(220,100,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("mobility +20%",180,100);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(2,MSUp)*MSUpP)fill(0);
    text((int)Math.pow(2,MSUp)*MSUpP,220,100);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<116&&86<mouseY && frames<=0 && points>=(int)Math.pow(2,MSUp)*MSUpP){
      frames=15;
      points=points-(int)Math.pow(2,MSUp)*MSUpP;
      canon1.speed=canon1.speed*1.2f;
      MSUp++;
      table.getRow(2).setInt("value",MSUp);
      fill(0xffFFFFFF);
      rect(220,150,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("mobility +20%",180,100);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(2,MSUp)*MSUpP,220,100);
    }
    
    fill(0xffC6EFFF);
    rect(220,150,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("raindrops +20%",180,150);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(2,RDUp)*RDUpP)fill(0);
    text((int)Math.pow(2,RDUp)*RDUpP,220,150);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<166&&136<mouseY && frames<=0 && points>=(int)Math.pow(2,RDUp)*RDUpP){
      frames=15;
      points=points-(int)Math.pow(2,RDUp)*RDUpP;
      dropspeed=dropspeed*1.2f;
      RDUp++;
      table.getRow(3).setInt("value",RDUp);
      fill(0xffFFFFFF);
      rect(220,150,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("raindrops +10%",180,150);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(2,RDUp)*RDUpP,220,150);
    }
    
    fill(0xffC6EFFF);
    rect(220,250,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("beachballs",180,250);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,BBUp)*BBUpP)fill(0);
    text((int)Math.pow(5,BBUp)*BBUpP,220,250);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<266&&236<mouseY && frames<=0 && points>=(int)Math.pow(5,BBUp)*BBUpP){
      frames=15;
      points=points-(int)Math.pow(5,BBUp)*BBUpP;
      canon1.ballAS=canon1.ballAS*1.5f;
      BBUp++;
      table.getRow(4).setInt("value",BBUp);
      fill(0xffFFFFFF);
      rect(220,250,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("raindrops +10%",180,250);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,BBUp)*BBUpP,220,250);
    }
    
    fill(0xffC6EFFF);
    rect(220,350,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("Big Drops",180,350);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,BDUp)*BDUpP)fill(0);
    text((int)Math.pow(5,BDUp)*BDUpP,220,350);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<366&&336<mouseY && frames<=0 && points>=(int)Math.pow(5,BDUp)*BDUpP){
      frames=15;
      points=points-(int)Math.pow(5,BDUp)*BDUpP;
      BigDspeed=BigDspeed*1.5f;
      BDUp++;
      table.getRow(5).setInt("value",BDUp);
      fill(0xffFFFFFF);
      rect(220,350,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("Big Drops",180,350);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,BDUp)*BDUpP,220,350);
    }
    
    fill(0xffC6EFFF);
    rect(220,200,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("points +20%",180,200);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(2,PKUp)*PKUpP)fill(0);
    text((int)Math.pow(2,PKUp)*PKUpP,220,200);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<216&&186<mouseY && frames<=0 && points>=(int)Math.pow(2,PKUp)*PKUpP){
      frames=15;
      points=points-(int)Math.pow(2,PKUp)*PKUpP;
      pointsPKill=pointsPKill*1.2f;
      PKUp++;
      table.getRow(6).setInt("value",PKUp);
      fill(0xffFFFFFF);
      rect(220,200,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("points +20%",180,200);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(2,PKUp)*PKUpP,220,200);
    }
    
    fill(0xffC6EFFF);
    rect(220,450,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("lost drops +20%",180,450);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,PMUp)*PMUpP)fill(0);
    if(PMUp<=1)text((int)Math.pow(5,PMUp)*PMUpP,220,450);
    else text("max",220,450);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<466&&436<mouseY && frames<=0 && points>=(int)Math.pow(5,PMUp)*PMUpP && PMUp<=1){
      frames=15;
      points=points-(int)Math.pow(5,PMUp)*PMUpP;
      PMUp++;
      table.getRow(7).setInt("value",PMUp);
      fill(0xffFFFFFF);
      rect(220,450,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("lost drops +20%",180,450);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,PMUp)*PMUpP,220,450);
    }
    
    fill(0xffC6EFFF);
    rect(220,400,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("bigger Bullets",180,400);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,BBulletsUp)*BBulletsUpP)fill(0);
    if(BBulletsUp<=6)text((int)Math.pow(5,BBulletsUp)*BBulletsUpP,220,400);
    else text("max",220,400);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<416&&386<mouseY && frames<=0 && points>=(int)Math.pow(5,BBulletsUp)*BBulletsUpP && BBulletsUp<=6){
      frames=15;
      points=points-(int)Math.pow(5,BBulletsUp)*BBulletsUpP;
      canon1.bulletSize=canon1.bulletSize*1.2f;
      BBulletsUp++;
      table.getRow(8).setInt("value",BBulletsUp);
      fill(0xffFFFFFF);
      rect(220,400,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("bigger Bullets",180,400);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,BBulletsUp)*BBulletsUpP,220,400);
    }
    
    fill(0xffC6EFFF);
    rect(220,550,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("glowing Drops",180,550);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,GlowDUp)*GlowDUpP)fill(0);
    text((int)Math.pow(5,GlowDUp)*GlowDUpP,220,550);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<566&&536<mouseY && frames<=0 && points>=(int)Math.pow(5,GlowDUp)*GlowDUpP){
      frames=15;
      points=points-(int)Math.pow(5,GlowDUp)*GlowDUpP;
      GlowDspeed=GlowDspeed*1.5f;
      GlowDUp++;
      table.getRow(9).setInt("value",GlowDUp);
      fill(0xffFFFFFF);
      rect(220,550,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("glowing Drops",180,550);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,GlowDUp)*GlowDUpP,220,550);
    }
    
    fill(0xffC6EFFF);
    rect(220,500,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("trinity shot",180,500);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,TrinityUp)*TrinityUpP)fill(0);
    if(TrinityUp<=3)text((int)Math.pow(5,TrinityUp)*TrinityUpP,220,500);
    else text("max",220,500);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<516&&486<mouseY && frames<=0 && points>=(int)Math.pow(5,TrinityUp)*TrinityUpP && TrinityUp<=3){
      frames=15;
      points=points-(int)Math.pow(5,TrinityUp)*TrinityUpP;
      canon1.trinityChance=canon1.trinityChance+25;
      TrinityUp++;
      table.getRow(10).setInt("value",TrinityUp);
      fill(0xffFFFFFF);
      rect(220,500,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("trinity shot",180,500);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,TrinityUp)*TrinityUpP,220,500);
    }
    
    fill(0xffC6EFFF);
    rect(220,300,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("trippledrop Mode",180,300);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,ShowerUp)*ShowerUpP)fill(0);
    if(ShowerUp<=4)text((int)Math.pow(5,ShowerUp)*ShowerUpP,220,300);
    else text("max",220,300);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<316&&286<mouseY && frames<=0 && points>=(int)Math.pow(5,ShowerUp)*ShowerUpP && ShowerUp<=4){
      frames=15;
      points=points-(int)Math.pow(5,ShowerUp)*ShowerUpP;
      ShowerTime=3.5f+1.5f*shop.ShowerUp;
      ShowerUp++;
      table.getRow(11).setInt("value",ShowerUp);
      fill(0xffFFFFFF);
      rect(220,300,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("trippledrop Mode",180,300);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,ShowerUp)*ShowerUpP,220,300);
    }
    
    fill(0xffC6EFFF);
    rect(220,600,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("BOMBS",180,600);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,BombsUp)*BombsUpP)fill(0);
    text((int)Math.pow(5,BombsUp)*BombsUpP,220,600);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<616&&586<mouseY && frames<=0 && points>=(int)Math.pow(5,BombsUp)*BombsUpP){
      frames=15;
      points=points-(int)Math.pow(5,BombsUp)*BombsUpP;
      canon1.bombAS=canon1.bombAS*1.5f;
      BombsUp++;
      table.getRow(12).setInt("value",BombsUp);
      fill(0xffFFFFFF);
      rect(220,600,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("BOMBS",180,600);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,BombsUp)*BombsUpP,220,600);
    }
    
    fill(0xffC6EFFF);
    rect(220,650,64,32);
    fill(0);
    textSize(16);
    textAlign(RIGHT,CENTER);
    text("Halo Drops",180,650);
    textAlign(CENTER,CENTER);
    textSize(10);
    fill(0xff939393);
    if(points>=(int)Math.pow(5,HaloDUp)*HaloDUpP)fill(0);
    text((int)Math.pow(5,HaloDUp)*HaloDUpP,220,650);
    if(mousePressed && mouseX<252&&188<mouseX && mouseY<666&&636<mouseY && frames<=0 && points>=(int)Math.pow(5,HaloDUp)*HaloDUpP){
      frames=15;
      points=points-(int)Math.pow(5,HaloDUp)*HaloDUpP;
      HaloSpeed=HaloSpeed*1.5f;
      HaloDUp++;
      table.getRow(13).setInt("value",HaloDUp);
      fill(0xffFFFFFF);
      rect(220,650,64,32);
      textSize(16);
      textAlign(RIGHT,CENTER);
      text("Halo Drops",180,650);
      textAlign(CENTER,CENTER);
      textSize(10);
      text((int)Math.pow(5,HaloDUp)*HaloDUpP,220,650);
    }
  }
}
class canon{
  
  float posX;
  float speed;
  
  float nextShot;
  float attackspeed;
  float bulletSize=20;
  float trinityChance=0;
  
  float nextBall=20;
  float ballAS=5;
  
  float nextBomb=3600/4;
  float bombAS=3;
  
  canon(){
    posX=400;
    speed=5;
    nextShot=20;
    attackspeed=80;
  }
  public void draw(){
    if(keys[0] && posX>0)posX=posX-speed/screenSize;
    if(keys[1] && posX<800)posX=posX+speed/screenSize;
    fill(0xffFDFFE0);
    image(canonI,posX,800-40/screenSize,50/screenSize,50/screenSize);
    shoot();
  }
  
  public void shoot(){
    if(nextShot<=0){
      Bullet bullet=new Bullet(posX,800-40/screenSize,0,-14,bulletSize,0);
      if(random(100)<trinityChance){
        Bullet bullet2=new Bullet(posX,800-40/screenSize,10,-10,bulletSize,45);
        Bullet bullet3=new Bullet(posX,800-40/screenSize,-10,-10,bulletSize,-45);
      }
      nextShot=3600/attackspeed;
    }else{
      nextShot--;
    }
    
    if(nextBall<=0 && shop.BBUp>0){
      float ballSX=random(-12,12);
      float ballSY=-8;
      float param=10/ (float)Math.sqrt(Math.pow(ballSX,2)+Math.pow(ballSY,2));
      
      Ball ball=new Ball(posX,800-40/screenSize,ballSX*param,ballSY*param);
      nextBall=3600/ballAS;
    }
    if(shop.BBUp>0)nextBall--;
    
    if(nextBomb<=0 && shop.BombsUp>0){
      float bombSX=random(-12,12);
      float bombSY=-8;
      float param=10/ (float)Math.sqrt(Math.pow(bombSX,2)+Math.pow(bombSY,2));
      
      Bomb bomb1=new Bomb(posX,800-40/screenSize,bombSX*param,bombSY*param);
      nextBomb=3600/bombAS;
    }
    if(shop.BBUp>0)nextBomb--;
  }
}
  public void settings() {  size(800,800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "clicker" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
